import streamlit as st
import numpy as np
import cv2
import requests
from io import BytesIO
from descriptor import glcm_image, bitdesc_image
from distances import retrieve_similar_images

# Charger les signatures sauvegardées
signatures = np.load('signatures.npy')

# Interface utilisateur avec Streamlit
st.title('Recherche d\'Images Basée sur le Contenu')

# Disposition en colonnes
col1, col2 = st.columns(2)

with col1:
    # Choix du mode de téléchargement d'image
    mode = st.radio("Télécharger une image par", ("Fichier", "URL"))

    img = None  # Initialisation de la variable img

    # Téléchargement d'image par l'utilisateur
    if mode == "Fichier":
        uploaded_file = st.file_uploader("Téléchargez une image", type=["jpg", "jpeg", "png"])
        if uploaded_file is not None:
            file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
            img = cv2.imdecode(file_bytes, cv2.IMREAD_GRAYSCALE)
    else:
        url = st.text_input("Entrez l'URL de l'image")
        if url:
            try:
                response = requests.get(url)
                img_array = np.asarray(bytearray(response.content), dtype=np.uint8)
                img = cv2.imdecode(img_array, cv2.IMREAD_GRAYSCALE)
            except Exception as e:
                st.error(f"Erreur de chargement de l'image : {e}")

    # Vérifier si l'image a été chargée avec succès
    if img is not None:
        st.image(img, channels="GRAY", caption='Image téléchargée', use_column_width=True)
        
        # Sélection du descripteur
        descriptor_choice = st.selectbox("Choisissez un descripteur", ["GLCM", "Bit"])
        query_features = glcm_image(img) if descriptor_choice == "GLCM" else bitdesc_image(img)

        # Sélection de la mesure de distance
        distance_choice = st.selectbox("Choisissez une mesure de distance", ["Manhattan", "Euclidean", "Chebyshev", "Canberra"])
        
        # Sélection du nombre de résultats à afficher
        num_results = st.number_input("Nombre de résultats à afficher", min_value=1, max_value=20, value=5)

        # Bouton de recherche
        if st.button('Rechercher'):
            similar_images = retrieve_similar_images(signatures, query_features, distance_choice.lower(), num_results)
            with col2:
                st.write(f"Les {num_results} images les plus similaires :")
                for img_path, dist, label in similar_images:
                    st.image(img_path, caption=f"Distance: {dist:.2f} | Label: {label}", use_column_width=True)
    else:
        st.error("Aucune image valide chargée. Veuillez télécharger ou entrer une URL valide.")
